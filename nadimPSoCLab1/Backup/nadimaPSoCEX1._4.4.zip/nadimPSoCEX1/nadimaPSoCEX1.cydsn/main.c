/* ========================================
 *
 * Copyright Nadim Ahmed, Metropolia UAS, Finland, 2024
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 *CC-NA-SA 4.0
 *
 * ========================================
*/
#include "project.h"

int main(void)
{   
    //uint8 blnk = 0;
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        /* Place your application code here. */
        //LED1_Write(blnk++ % 2);
        /*LED1_Write(1);
        CyDelay(200);
        LED1_Write(0);
        CyDelay(800);
        */
        if(Button_Read()){
            LED1_Write(1);
        }
    }
}

/* [] END OF FILE */
